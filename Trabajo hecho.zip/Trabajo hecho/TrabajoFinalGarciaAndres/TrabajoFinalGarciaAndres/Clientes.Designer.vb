﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Clientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        dgvclientes = New DataGridView()
        Button1 = New Button()
        Button2 = New Button()
        CType(dgvclientes, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' dgvclientes
        ' 
        dgvclientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvclientes.Location = New Point(259, 21)
        dgvclientes.Name = "dgvclientes"
        dgvclientes.Size = New Size(496, 354)
        dgvclientes.TabIndex = 0
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(54, 147)
        Button1.Name = "Button1"
        Button1.Size = New Size(139, 82)
        Button1.TabIndex = 1
        Button1.Text = "Ingresar cliente"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(589, 384)
        Button2.Name = "Button2"
        Button2.Size = New Size(141, 54)
        Button2.TabIndex = 2
        Button2.Text = "Actualizar"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Clientes
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(dgvclientes)
        Name = "Clientes"
        Text = "Clientes"
        CType(dgvclientes, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents dgvclientes As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
