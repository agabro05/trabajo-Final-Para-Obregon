﻿Imports MySql.Data.MySqlClient

Public Class Productos

    Private cadenaConexion As String = "Server=127.0.0.1;Port=3000;Database=trabajo;User=root;Password=;"


    Private idProductoSeleccionado As Integer = 0

    Private Sub FormularioProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        nudPrecio.Maximum = 9999999
        nudPrecio.DecimalPlaces = 0


        CargarGrillaProductos()
    End Sub

    Private Sub CargarGrillaProductos()
        Try
            Using con As New MySqlConnection(cadenaConexion)
                con.Open()
                Dim query As String = "SELECT ID, Nombre, Precio, Categoria FROM productos"
                Dim adapter As New MySqlDataAdapter(query, con)
                Dim dt As New DataTable()
                adapter.Fill(dt)


                dgvProductos.DataSource = dt


                dgvProductos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar los productos: " & ex.Message)
        End Try
    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click

        If String.IsNullOrWhiteSpace(txtNombre.Text) Then
            MessageBox.Show("Debe ingresar un nombre.")
            Return
        End If

        If nudPrecio.Value = 0 Then
            MessageBox.Show("Debe ingresar un precio mayor a 0.")
            Return
        End If

        Dim query As String = ""


        If idProductoSeleccionado = 0 Then

            query = "INSERT INTO productos (Nombre, Precio, Categoria) VALUES (@Nombre, @Precio, @Categoria)"
        Else

            query = "UPDATE productos SET Nombre = @Nombre, Precio = @Precio, Categoria = @Categoria WHERE ID = @ID"
        End If

        Try
            Using con As New MySqlConnection(cadenaConexion)
                con.Open()
                Dim cmd As New MySqlCommand(query, con)


                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text)
                cmd.Parameters.AddWithValue("@Precio", nudPrecio.Value)
                cmd.Parameters.AddWithValue("@Categoria", txtCategoria.Text)


                If idProductoSeleccionado > 0 Then
                    cmd.Parameters.AddWithValue("@ID", idProductoSeleccionado)
                End If


                cmd.ExecuteNonQuery()


                If idProductoSeleccionado = 0 Then
                    MessageBox.Show("Producto guardado exitosamente.")
                Else
                    MessageBox.Show("Producto actualizado exitosamente.")
                End If


                CargarGrillaProductos()
                LimpiarCampos()

            End Using
        Catch ex As Exception
            MessageBox.Show("Error al guardar el producto: " + ex.Message)
        End Try
    End Sub

    Private Sub dgvProductos_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProductos.CellClick

        If e.RowIndex >= 0 Then
            Dim filaSeleccionada As DataGridViewRow = dgvProductos.Rows(e.RowIndex)


            idProductoSeleccionado = Convert.ToInt32(filaSeleccionada.Cells("ID").Value)
            txtNombre.Text = filaSeleccionada.Cells("Nombre").Value.ToString()
            nudPrecio.Value = Convert.ToDecimal(filaSeleccionada.Cells("Precio").Value)
            txtCategoria.Text = filaSeleccionada.Cells("Categoria").Value.ToString()


            btnGuardar.Text = "Actualizar"

            btnEliminar.Enabled = True
        End If
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        LimpiarCampos()
    End Sub

    Private Sub LimpiarCampos()

        idProductoSeleccionado = 0
        txtNombre.Clear()
        nudPrecio.Value = 0
        txtCategoria.Clear()

        btnGuardar.Text = "Guardar"

        btnEliminar.Enabled = False


        txtNombre.Focus()
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click

        If idProductoSeleccionado = 0 Then
            MessageBox.Show("Debe seleccionar un producto de la grilla para eliminar.")
            Return
        End If

        ' Pregunta de confirmación
        Dim confirmacion = MessageBox.Show($"¿Está seguro que desea eliminar el producto '{txtNombre.Text}'?",
                                           "Confirmar eliminación",
                                           MessageBoxButtons.YesNo,
                                           MessageBoxIcon.Warning)

        If confirmacion = DialogResult.Yes Then
            ' El usuario dijo que SÍ
            Try
                Using con As New MySqlConnection(cadenaConexion)
                    con.Open()
                    Dim query As String = "DELETE FROM productos WHERE ID = @ID"
                    Dim cmd As New MySqlCommand(query, con)
                    cmd.Parameters.AddWithValue("@ID", idProductoSeleccionado)

                    cmd.ExecuteNonQuery()

                    MessageBox.Show("Producto eliminado.")

                    ' Recargamos la grilla y limpiamos
                    CargarGrillaProductos()
                    LimpiarCampos()
                End Using
            Catch ex As Exception
                MessageBox.Show("Error al eliminar: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Menu.Show()
        Me.Hide()

    End Sub
End Class