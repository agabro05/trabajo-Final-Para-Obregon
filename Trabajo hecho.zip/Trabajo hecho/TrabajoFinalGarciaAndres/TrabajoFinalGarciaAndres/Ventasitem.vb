﻿Imports MySql.Data.MySqlClient

Public Class Ventasitem
    Private cadenaConexion As String = "Server=127.0.0.1;Port=3000;Database=trabajo;User=root;Password=;"
    Private dtProductos As New DataTable()
    Private dtClientes As New DataTable()
    Private totalGeneral As Decimal = 0

    Private Sub FormularioVentas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConfigurarGrilla()
        CargarClientes()
        CargarProductos()
        nudCantidad.Minimum = 1
        nudCantidad.Value = 1
        lblTotal.Text = "Total: $0.00"
    End Sub

    Private Sub ConfigurarGrilla()

        dgvItemsVenta.Columns.Clear()


        dgvItemsVenta.Columns.Add("IdProducto", "ID Producto")
        dgvItemsVenta.Columns.Add("Producto", "Producto")
        dgvItemsVenta.Columns.Add("PrecioUnitario", "Precio Unit.")
        dgvItemsVenta.Columns.Add("Cantidad", "Cantidad")
        dgvItemsVenta.Columns.Add("Subtotal", "Subtotal")


        dgvItemsVenta.Columns("IdProducto").Visible = False


        dgvItemsVenta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Private Sub CargarClientes()

        Try
            Using con As New MySqlConnection(cadenaConexion)
                con.Open()
                Dim query As String = "SELECT ID, Clientes FROM clientes"
                Dim adapter As New MySqlDataAdapter(query, con)
                adapter.Fill(dtClientes)


                dtClientes.PrimaryKey = New DataColumn() {dtClientes.Columns("ID")}


                cboClientes.DataSource = dtClientes
                cboClientes.DisplayMember = "Clientes"
                cboClientes.ValueMember = "ID"
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar clientes: " & ex.Message)
        End Try
    End Sub

    Private Sub CargarProductos()

        Try
            Using con As New MySqlConnection(cadenaConexion)
                con.Open()
                Dim query As String = "SELECT ID, Nombre, Precio FROM productos"
                Dim adapter As New MySqlDataAdapter(query, con)
                adapter.Fill(dtProductos)


                dtProductos.PrimaryKey = New DataColumn() {dtProductos.Columns("ID")}


                cboProductos.DataSource = dtProductos
                cboProductos.DisplayMember = "Nombre"
                cboProductos.ValueMember = "ID"
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar productos: " & ex.Message)
        End Try
    End Sub

    Private Sub btnAgregarItem_Click(sender As Object, e As EventArgs) Handles btnAgregarItem.Click

        Dim filaProducto As DataRow = dtProductos.Rows.Find(cboProductos.SelectedValue)

        If filaProducto Is Nothing Then
            MessageBox.Show("Debe seleccionar un producto.")
            Return
        End If

        Dim idProducto As Integer = Convert.ToInt32(filaProducto("ID"))
        Dim nombreProducto As String = filaProducto("Nombre").ToString()
        Dim precioUnitario As Decimal = Convert.ToDecimal(filaProducto("Precio"))


        Dim cantidad As Integer = Convert.ToInt32(nudCantidad.Value)


        Dim subtotal As Decimal = precioUnitario * cantidad


        dgvItemsVenta.Rows.Add(idProducto, nombreProducto, precioUnitario, cantidad, subtotal)


        totalGeneral += subtotal
        lblTotal.Text = $"Total: ${totalGeneral:F2}"


        nudCantidad.Value = 1
        cboProductos.Focus()
    End Sub

    Private Sub btnGuardarVenta_Click(sender As Object, e As EventArgs) Handles btnGuardarVenta.Click


        If cboClientes.SelectedValue Is Nothing Then
            MessageBox.Show("Debe seleccionar un cliente.")
            Return
        End If


        Dim filasUtiles As Integer = 0
        For Each fila As DataGridViewRow In dgvItemsVenta.Rows
            If Not fila.IsNewRow Then
                filasUtiles += 1
            End If
        Next

        If filasUtiles = 0 Then
            MessageBox.Show("Debe agregar al menos un producto a la venta.")
            Return
        End If


        Dim idCliente As Integer = Convert.ToInt32(cboClientes.SelectedValue)
        Dim fechaVenta As DateTime = DateTime.Now


        Using con As New MySqlConnection(cadenaConexion)
            con.Open()
            Dim transaccion As MySqlTransaction = con.BeginTransaction()

            Try

                Dim queryVenta As String = "INSERT INTO ventas (IDcliente, Fecha, Total) VALUES (@IDcliente, @Fecha, @Total); SELECT LAST_INSERT_ID();"
                Dim cmdVenta As New MySqlCommand(queryVenta, con, transaccion)

                cmdVenta.Parameters.AddWithValue("@IDcliente", idCliente)
                cmdVenta.Parameters.AddWithValue("@Fecha", fechaVenta)
                cmdVenta.Parameters.AddWithValue("@Total", totalGeneral)

                Dim idVentaGenerado As Long = Convert.ToInt64(cmdVenta.ExecuteScalar())


                Dim queryItem As String = "INSERT INTO ventasitems (IdVenta, IdProducto, Cantidad, PrecioUnitario, PrecioTotal) " &
                                      "VALUES (@IdVenta, @IdProducto, @Cantidad, @PrecioUnitario, @PrecioTotal)"
                Dim cmdItem As New MySqlCommand(queryItem, con, transaccion)


                For Each fila As DataGridViewRow In dgvItemsVenta.Rows


                    If Not fila.IsNewRow Then


                        cmdItem.Parameters.Clear()

                        cmdItem.Parameters.AddWithValue("@IdVenta", idVentaGenerado) ' El ID que obtuvimos
                        cmdItem.Parameters.AddWithValue("@IdProducto", Convert.ToInt32(fila.Cells("IdProducto").Value))
                        cmdItem.Parameters.AddWithValue("@Cantidad", Convert.ToInt32(fila.Cells("Cantidad").Value))
                        cmdItem.Parameters.AddWithValue("@PrecioUnitario", Convert.ToDecimal(fila.Cells("PrecioUnitario").Value))
                        cmdItem.Parameters.AddWithValue("@PrecioTotal", Convert.ToDecimal(fila.Cells("Subtotal").Value))

                        cmdItem.ExecuteNonQuery()
                    End If

                Next


                transaccion.Commit()

                MessageBox.Show($"Venta N° {idVentaGenerado} guardada exitosamente.")
                LimpiarFormulario()

            Catch ex As Exception
                transaccion.Rollback()
                MessageBox.Show("Error al guardar la venta: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub LimpiarFormulario()

        dgvItemsVenta.Rows.Clear()
        totalGeneral = 0
        lblTotal.Text = "Total: $0.00"
        cboClientes.SelectedIndex = -1
        cboProductos.SelectedIndex = -1
        nudCantidad.Value = 1
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Menu.Show()
        Me.Hide()

    End Sub
End Class