﻿
Public Class altacliente

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Dim nombre As String = txtNombreCliente.Text
        Dim tel As String = txtTelefono.Text
        Dim correo As String = txtCorreo.Text


        If String.IsNullOrWhiteSpace(nombre) Then
            MessageBox.Show("El nombre del cliente es obligatorio.", "Dato faltante", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If


        Dim db As New UsuarioDatos()
        Try
            db.GuardarCliente(nombre, tel, correo)

            MessageBox.Show("¡Cliente guardado con éxito!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)


            Me.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Menu.Show()
        Me.Hide()
    End Sub

End Class