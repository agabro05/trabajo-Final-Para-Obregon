﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCrearuser
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        txtdni2 = New TextBox()
        txtnombre2 = New TextBox()
        txtapellido2 = New TextBox()
        txtcontraseña2 = New TextBox()
        Label5 = New Label()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(167, 157)
        Label1.Name = "Label1"
        Label1.Size = New Size(27, 15)
        Label1.TabIndex = 0
        Label1.Text = "DNI"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(167, 254)
        Label2.Name = "Label2"
        Label2.Size = New Size(104, 15)
        Label2.TabIndex = 1
        Label2.Text = "Nueva Contraseña"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(167, 191)
        Label3.Name = "Label3"
        Label3.Size = New Size(51, 15)
        Label3.TabIndex = 2
        Label3.Text = "Nombre"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(167, 225)
        Label4.Name = "Label4"
        Label4.Size = New Size(51, 15)
        Label4.TabIndex = 3
        Label4.Text = "Apellido"
        ' 
        ' txtdni2
        ' 
        txtdni2.Location = New Point(277, 154)
        txtdni2.Name = "txtdni2"
        txtdni2.Size = New Size(209, 23)
        txtdni2.TabIndex = 4
        ' 
        ' txtnombre2
        ' 
        txtnombre2.Location = New Point(277, 188)
        txtnombre2.Name = "txtnombre2"
        txtnombre2.Size = New Size(209, 23)
        txtnombre2.TabIndex = 5
        ' 
        ' txtapellido2
        ' 
        txtapellido2.Location = New Point(277, 222)
        txtapellido2.Name = "txtapellido2"
        txtapellido2.Size = New Size(209, 23)
        txtapellido2.TabIndex = 6
        ' 
        ' txtcontraseña2
        ' 
        txtcontraseña2.Location = New Point(277, 251)
        txtcontraseña2.Name = "txtcontraseña2"
        txtcontraseña2.Size = New Size(209, 23)
        txtcontraseña2.TabIndex = 7
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(167, 99)
        Label5.Name = "Label5"
        Label5.Size = New Size(97, 15)
        Label5.TabIndex = 8
        Label5.Text = "Ingrese sus datos"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(277, 348)
        Button1.Name = "Button1"
        Button1.Size = New Size(174, 69)
        Button1.TabIndex = 9
        Button1.Text = "Guardar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' FormCrearuser
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button1)
        Controls.Add(Label5)
        Controls.Add(txtcontraseña2)
        Controls.Add(txtapellido2)
        Controls.Add(txtnombre2)
        Controls.Add(txtdni2)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "FormCrearuser"
        Text = "FormCrearuser"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtdni2 As TextBox
    Friend WithEvents txtnombre2 As TextBox
    Friend WithEvents txtapellido2 As TextBox
    Friend WithEvents txtcontraseña2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Button1 As Button
End Class
