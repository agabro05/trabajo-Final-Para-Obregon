﻿Imports MySql.Data.MySqlClient

Public Class MenuVentas
    Private cadenaConexion As String = "Server=127.0.0.1;Port=3000;Database=trabajo;User=root;Password=;"
    Private Sub MenuVentas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        CargarGrillaVentas()
    End Sub
    Private Sub CargarGrillaVentas()
        Try
            Using con As New MySqlConnection(cadenaConexion)
                con.Open()


                Dim query As String = "SELECT v.ID, c.Clientes, v.Fecha, v.Total " &
                                      "FROM ventas v " &
                                      "JOIN clientes c ON v.IDcliente = c.ID " &
                                      "ORDER BY v.ID DESC" ' 

                Dim adapter As New MySqlDataAdapter(query, con)
                Dim dt As New DataTable()
                adapter.Fill(dt)


                dgvventas.DataSource = dt


                dgvventas.Columns("ID").Width = 50
                dgvventas.Columns("Clientes").HeaderText = "Cliente"
                dgvventas.Columns("Total").DefaultCellStyle.Format = "c2"


                dgvventas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
                dgvventas.Columns("ID").AutoSizeMode = DataGridViewAutoSizeColumnsMode.None

            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar las ventas: " & ex.Message)
        End Try
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Menu.Show()
        Me.Hide()
    End Sub

    Private Sub dgvventas_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvventas.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Ventasitem.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CargarGrillaVentas()
    End Sub
End Class