﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuVentas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        dgvventas = New DataGridView()
        Button2 = New Button()
        Button3 = New Button()
        Button1 = New Button()
        CType(dgvventas, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' dgvventas
        ' 
        dgvventas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvventas.Location = New Point(253, 33)
        dgvventas.Name = "dgvventas"
        dgvventas.Size = New Size(449, 325)
        dgvventas.TabIndex = 0
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(36, 381)
        Button2.Name = "Button2"
        Button2.Size = New Size(130, 57)
        Button2.TabIndex = 2
        Button2.Text = "Volver"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(549, 381)
        Button3.Name = "Button3"
        Button3.Size = New Size(153, 52)
        Button3.TabIndex = 3
        Button3.Text = "Actualizar"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(36, 172)
        Button1.Name = "Button1"
        Button1.Size = New Size(130, 77)
        Button1.TabIndex = 4
        Button1.Text = "Alta"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' MenuVentas
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button1)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(dgvventas)
        Name = "MenuVentas"
        Text = "MenuVentas"
        CType(dgvventas, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents dgvventas As DataGridView
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button1 As Button
End Class
