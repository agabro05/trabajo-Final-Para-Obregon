﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ventasitem
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cboClientes = New ComboBox()
        cboProductos = New ComboBox()
        nudCantidad = New NumericUpDown()
        btnAgregarItem = New Button()
        dgvItemsVenta = New DataGridView()
        lblTotal = New Label()
        btnGuardarVenta = New Button()
        Button1 = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        CType(nudCantidad, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvItemsVenta, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' cboClientes
        ' 
        cboClientes.FormattingEnabled = True
        cboClientes.Location = New Point(135, 57)
        cboClientes.Name = "cboClientes"
        cboClientes.Size = New Size(171, 23)
        cboClientes.TabIndex = 0
        ' 
        ' cboProductos
        ' 
        cboProductos.FormattingEnabled = True
        cboProductos.Location = New Point(135, 122)
        cboProductos.Name = "cboProductos"
        cboProductos.Size = New Size(171, 23)
        cboProductos.TabIndex = 1
        ' 
        ' nudCantidad
        ' 
        nudCantidad.Location = New Point(135, 188)
        nudCantidad.Name = "nudCantidad"
        nudCantidad.Size = New Size(171, 23)
        nudCantidad.TabIndex = 2
        ' 
        ' btnAgregarItem
        ' 
        btnAgregarItem.Location = New Point(79, 265)
        btnAgregarItem.Name = "btnAgregarItem"
        btnAgregarItem.Size = New Size(134, 57)
        btnAgregarItem.TabIndex = 3
        btnAgregarItem.Text = "Agregar"
        btnAgregarItem.UseVisualStyleBackColor = True
        ' 
        ' dgvItemsVenta
        ' 
        dgvItemsVenta.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvItemsVenta.Location = New Point(419, 40)
        dgvItemsVenta.Name = "dgvItemsVenta"
        dgvItemsVenta.Size = New Size(369, 333)
        dgvItemsVenta.TabIndex = 4
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(458, 401)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(0, 15)
        lblTotal.TabIndex = 5
        ' 
        ' btnGuardarVenta
        ' 
        btnGuardarVenta.Location = New Point(606, 379)
        btnGuardarVenta.Name = "btnGuardarVenta"
        btnGuardarVenta.Size = New Size(164, 58)
        btnGuardarVenta.TabIndex = 6
        btnGuardarVenta.Text = "Guardar"
        btnGuardarVenta.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(67, 371)
        Button1.Name = "Button1"
        Button1.Size = New Size(146, 67)
        Button1.TabIndex = 7
        Button1.Text = "Volver"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(34, 60)
        Label1.Name = "Label1"
        Label1.Size = New Size(44, 15)
        Label1.TabIndex = 8
        Label1.Text = "Cliente"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(34, 125)
        Label2.Name = "Label2"
        Label2.Size = New Size(56, 15)
        Label2.TabIndex = 9
        Label2.Text = "Producto"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(37, 190)
        Label3.Name = "Label3"
        Label3.Size = New Size(55, 15)
        Label3.TabIndex = 10
        Label3.Text = "Cantidad"
        ' 
        ' Ventasitem
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Button1)
        Controls.Add(btnGuardarVenta)
        Controls.Add(lblTotal)
        Controls.Add(dgvItemsVenta)
        Controls.Add(btnAgregarItem)
        Controls.Add(nudCantidad)
        Controls.Add(cboProductos)
        Controls.Add(cboClientes)
        Name = "Ventasitem"
        Text = "Ventasitem"
        CType(nudCantidad, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvItemsVenta, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cboClientes As ComboBox
    Friend WithEvents cboProductos As ComboBox
    Friend WithEvents nudCantidad As NumericUpDown
    Friend WithEvents btnAgregarItem As Button
    Friend WithEvents dgvItemsVenta As DataGridView
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnGuardarVenta As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
End Class
