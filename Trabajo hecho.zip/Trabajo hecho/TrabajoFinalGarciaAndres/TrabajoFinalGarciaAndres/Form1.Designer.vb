﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Button1 = New Button()
        Label2 = New Label()
        Label3 = New Label()
        txtdni1 = New TextBox()
        txtcontraseña1 = New TextBox()
        Label4 = New Label()
        Button2 = New Button()
        Button3 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(282, 65)
        Label1.Name = "Label1"
        Label1.Size = New Size(197, 15)
        Label1.TabIndex = 0
        Label1.Text = "Hola! Ingresa tu DNI y tu contraseña"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(323, 329)
        Button1.Name = "Button1"
        Button1.Size = New Size(108, 81)
        Button1.TabIndex = 1
        Button1.Text = "Ingresar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(187, 187)
        Label2.Name = "Label2"
        Label2.Size = New Size(27, 15)
        Label2.TabIndex = 2
        Label2.Text = "DNI"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(187, 241)
        Label3.Name = "Label3"
        Label3.Size = New Size(67, 15)
        Label3.TabIndex = 3
        Label3.Text = "Contraseña"
        ' 
        ' txtdni1
        ' 
        txtdni1.Location = New Point(282, 179)
        txtdni1.Name = "txtdni1"
        txtdni1.Size = New Size(209, 23)
        txtdni1.TabIndex = 4
        ' 
        ' txtcontraseña1
        ' 
        txtcontraseña1.Location = New Point(282, 233)
        txtcontraseña1.Name = "txtcontraseña1"
        txtcontraseña1.Size = New Size(209, 23)
        txtcontraseña1.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(631, 395)
        Label4.Name = "Label4"
        Label4.Size = New Size(66, 15)
        Label4.TabIndex = 7
        Label4.Text = "Sos nuevo?"
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(604, 431)
        Button2.Name = "Button2"
        Button2.Size = New Size(131, 55)
        Button2.TabIndex = 8
        Button2.Text = "Crear cuenta"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(12, 459)
        Button3.Name = "Button3"
        Button3.Size = New Size(127, 59)
        Button3.TabIndex = 9
        Button3.Text = "Salir"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 530)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Label4)
        Controls.Add(txtcontraseña1)
        Controls.Add(txtdni1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Button1)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtdni1 As TextBox
    Friend WithEvents txtcontraseña1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button

End Class
