﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Productos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        txtNombre = New TextBox()
        txtCategoria = New TextBox()
        nudPrecio = New NumericUpDown()
        btnGuardar = New Button()
        btnEliminar = New Button()
        btnLimpiar = New Button()
        dgvProductos = New DataGridView()
        Button1 = New Button()
        CType(nudPrecio, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvProductos, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(21, 87)
        Label1.Name = "Label1"
        Label1.Size = New Size(51, 15)
        Label1.TabIndex = 0
        Label1.Text = "Nombre"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(21, 142)
        Label2.Name = "Label2"
        Label2.Size = New Size(40, 15)
        Label2.TabIndex = 1
        Label2.Text = "Precio"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(21, 199)
        Label3.Name = "Label3"
        Label3.Size = New Size(58, 15)
        Label3.TabIndex = 2
        Label3.Text = "Categoria"
        ' 
        ' txtNombre
        ' 
        txtNombre.Location = New Point(103, 79)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(208, 23)
        txtNombre.TabIndex = 4
        ' 
        ' txtCategoria
        ' 
        txtCategoria.Location = New Point(103, 196)
        txtCategoria.Name = "txtCategoria"
        txtCategoria.Size = New Size(208, 23)
        txtCategoria.TabIndex = 6
        ' 
        ' nudPrecio
        ' 
        nudPrecio.Location = New Point(100, 140)
        nudPrecio.Name = "nudPrecio"
        nudPrecio.Size = New Size(211, 23)
        nudPrecio.TabIndex = 8
        ' 
        ' btnGuardar
        ' 
        btnGuardar.Location = New Point(194, 304)
        btnGuardar.Name = "btnGuardar"
        btnGuardar.Size = New Size(150, 57)
        btnGuardar.TabIndex = 9
        btnGuardar.Text = "Guardar"
        btnGuardar.UseVisualStyleBackColor = True
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Location = New Point(21, 381)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(150, 57)
        btnEliminar.TabIndex = 10
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnLimpiar
        ' 
        btnLimpiar.Location = New Point(21, 304)
        btnLimpiar.Name = "btnLimpiar"
        btnLimpiar.Size = New Size(150, 57)
        btnLimpiar.TabIndex = 11
        btnLimpiar.Text = "Limpiar"
        btnLimpiar.UseVisualStyleBackColor = True
        ' 
        ' dgvProductos
        ' 
        dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvProductos.Location = New Point(371, 17)
        dgvProductos.Name = "dgvProductos"
        dgvProductos.Size = New Size(391, 400)
        dgvProductos.TabIndex = 12
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(196, 381)
        Button1.Name = "Button1"
        Button1.Size = New Size(150, 55)
        Button1.TabIndex = 13
        Button1.Text = "Volver"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Productos
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button1)
        Controls.Add(dgvProductos)
        Controls.Add(btnLimpiar)
        Controls.Add(btnEliminar)
        Controls.Add(btnGuardar)
        Controls.Add(nudPrecio)
        Controls.Add(txtCategoria)
        Controls.Add(txtNombre)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Productos"
        Text = "Productos"
        CType(nudPrecio, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvProductos, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents txtCategoria As TextBox
    Friend WithEvents nudPrecio As NumericUpDown
    Friend WithEvents btnGuardar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents dgvProductos As DataGridView
    Friend WithEvents Button1 As Button
End Class
