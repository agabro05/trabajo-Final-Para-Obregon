﻿Public Class Persona
    Public Property ID As Integer


    Private _dni As String
    Private _nombre As String
    Private _apellido As String



    Public Property DNI As String
        Get
            Return _dni
        End Get
        Set(value As String)
            If Not IsNumeric(value) Then
                Throw New Exception("El DNI debe contener solo números.")
            End If

            If value.Length <> 8 Then
                Throw New Exception("El DNI debe tener exactamente 8 dígitos.")
            End If

            _dni = value
        End Set
    End Property

    Public Property Nombre As String
        Get
            Return _Nombre
        End Get
        Set(value As String)
            If Not value.All(Function(c) Char.IsLetter(c) Or Char.IsWhiteSpace(c)) Then
                Throw New Exception("El nombre solo puede contener letras.")
            End If

            _Nombre = value
        End Set
    End Property

    Public Property Apellido As String
        Get
            Return _apellido
        End Get
        Set(value As String)
            If Not value.All(Function(c) Char.IsLetter(c) Or Char.IsWhiteSpace(c)) Then
                Throw New Exception("El apellido solo puede contener letras.")
            End If

            _apellido = value
        End Set
    End Property
End Class
