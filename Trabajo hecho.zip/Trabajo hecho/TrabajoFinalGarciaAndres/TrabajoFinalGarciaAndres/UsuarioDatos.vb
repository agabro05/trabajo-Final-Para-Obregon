﻿Imports MySql.Data.MySqlClient

Public Class UsuarioDatos

    Private ReadOnly connectionString As String = "Server=127.0.0.1;Port=3000;Database=trabajo;User=root;Password=;"



    Public Sub Guardar(user As Usuario)

        Dim conn As New MySqlConnection(connectionString)
        Dim cmd As MySqlCommand = Nothing

        Try
            conn.Open()


            Dim query As String = "INSERT INTO usuarios (DNI, Usuario, Apellido, Contraseña) VALUES (@dni, @usuario, @apellido, @pass)"

            cmd = New MySqlCommand(query, conn)


            cmd.Parameters.AddWithValue("@dni", user.DNI)
            cmd.Parameters.AddWithValue("@usuario", user.Nombre)
            cmd.Parameters.AddWithValue("@apellido", user.Apellido)
            cmd.Parameters.AddWithValue("@pass", user.Password)

            cmd.ExecuteNonQuery()

        Catch ex As MySqlException
            Throw New Exception("Error de base de datos: " & ex.Message)
        Finally
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try


    End Sub
    Public Function ValidarUsuario(dni As String, password As String) As Boolean

        Dim conn As New MySqlConnection(connectionString)
        Dim cmd As MySqlCommand = Nothing
        Dim resultado As Boolean = False

        Try
            conn.Open()


            Dim query As String = "SELECT COUNT(*) FROM usuarios WHERE DNI = @dni AND Contraseña = @pass"

            cmd = New MySqlCommand(query, conn)


            cmd.Parameters.AddWithValue("@dni", dni)
            cmd.Parameters.AddWithValue("@pass", password)


            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())


            If count = 1 Then
                resultado = True
            End If

        Catch ex As MySqlException

            Throw New Exception("Error no coincide: " & ex.Message)
        Finally

            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try


        Return resultado
    End Function
    Public Function ObtenerVentas() As DataTable


        Dim dt As New DataTable()


        Dim conn As New MySqlConnection(connectionString)

        Try

            Dim query As String = "SELECT * FROM ventas"
            Dim adapter As New MySqlDataAdapter(query, conn)
            adapter.Fill(dt)

        Catch ex As MySqlException

            Throw New Exception("Error de base de datos al cargar las ventas: " & ex.Message)
        End Try


        Return dt

    End Function
    Public Function ObtenerClientes() As DataTable
        Dim dt As New DataTable()
        Dim conn As New MySqlConnection(connectionString)

        Try

            Dim query As String = "SELECT * FROM clientes"


            Dim adapter As New MySqlDataAdapter(query, conn)


            adapter.Fill(dt)

        Catch ex As MySqlException
            Throw New Exception("Error de DB al cargar clientes: " & ex.Message)
        End Try


        Return dt
    End Function
    Public Sub GuardarCliente(nombreCliente As String, telefono As String, correo As String)
        Dim conn As New MySqlConnection(connectionString)
        Dim cmd As MySqlCommand = Nothing

        Try
            conn.Open()

            Dim query As String = "INSERT INTO clientes (Clientes, Telefono, Correo) VALUES (@nombre, @tel, @correo)"
            cmd = New MySqlCommand(query, conn)


            cmd.Parameters.AddWithValue("@nombre", nombreCliente)
            cmd.Parameters.AddWithValue("@tel", telefono)
            cmd.Parameters.AddWithValue("@correo", correo)

            cmd.ExecuteNonQuery()

        Catch ex As MySqlException
            Throw New Exception("Error de DB al guardar el cliente: " & ex.Message)
        Finally
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub

End Class
