﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class altacliente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtNombreCliente = New TextBox()
        txtTelefono = New TextBox()
        txtCorreo = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        SuspendLayout()
        ' 
        ' txtNombreCliente
        ' 
        txtNombreCliente.Location = New Point(200, 82)
        txtNombreCliente.Name = "txtNombreCliente"
        txtNombreCliente.Size = New Size(153, 23)
        txtNombreCliente.TabIndex = 0
        ' 
        ' txtTelefono
        ' 
        txtTelefono.Location = New Point(200, 132)
        txtTelefono.Name = "txtTelefono"
        txtTelefono.Size = New Size(153, 23)
        txtTelefono.TabIndex = 1
        ' 
        ' txtCorreo
        ' 
        txtCorreo.Location = New Point(200, 181)
        txtCorreo.Name = "txtCorreo"
        txtCorreo.Size = New Size(153, 23)
        txtCorreo.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(101, 85)
        Label1.Name = "Label1"
        Label1.Size = New Size(51, 15)
        Label1.TabIndex = 4
        Label1.Text = "Nombre"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(100, 132)
        Label2.Name = "Label2"
        Label2.Size = New Size(52, 15)
        Label2.TabIndex = 5
        Label2.Text = "Telefono"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(101, 184)
        Label3.Name = "Label3"
        Label3.Size = New Size(43, 15)
        Label3.TabIndex = 6
        Label3.Text = "Correo"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(101, 288)
        Button1.Name = "Button1"
        Button1.Size = New Size(185, 69)
        Button1.TabIndex = 7
        Button1.Text = "Guardar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(575, 332)
        Button2.Name = "Button2"
        Button2.Size = New Size(107, 63)
        Button2.TabIndex = 8
        Button2.Text = "Atras"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' altacliente
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtCorreo)
        Controls.Add(txtTelefono)
        Controls.Add(txtNombreCliente)
        Name = "altacliente"
        Text = "altacliente"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtNombreCliente As TextBox
    Friend WithEvents txtTelefono As TextBox
    Friend WithEvents txtCorreo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button


End Class
