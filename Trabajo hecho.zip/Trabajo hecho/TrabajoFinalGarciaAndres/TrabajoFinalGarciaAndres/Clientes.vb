﻿Public Class Clientes
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        altacliente.Show()
        Me.Hide()
    End Sub

    Private Sub Clientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarGrillaClientes()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CargarGrillaClientes()
    End Sub
    Private Sub CargarGrillaClientes()
        Dim db As New UsuarioDatos()
        Try

            Dim tabla As DataTable = db.ObtenerClientes()

            dgvclientes.DataSource = tabla

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error al cargar datos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class