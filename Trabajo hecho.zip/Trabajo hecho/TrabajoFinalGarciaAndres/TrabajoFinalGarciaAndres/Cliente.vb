﻿Public Class Cliente
    Inherits Persona
    Public Property Telefono As String
    Public Property Correo As String
End Class
