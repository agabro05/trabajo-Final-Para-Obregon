﻿
Public Class Usuario
    Inherits Persona
    Private _password As String


    Public Property Password As String
        Get
            Return _password
        End Get
        Set(value As String)
            If value.Length < 6 Then
                Throw New Exception("La contraseña debe tener al menos 6 caracteres.")
            End If

            _password = value
        End Set
    End Property

End Class


