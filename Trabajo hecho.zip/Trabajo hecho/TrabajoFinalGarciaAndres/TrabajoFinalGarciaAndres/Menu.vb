﻿Imports MySql.Data.MySqlClient

Public Class Menu
    Private cadenaConexion As String = "Server=127.0.0.1;Port=3000;Database=trabajo;User=root;Password=;"
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnVentas.Click
        MenuVentas.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Clientes.Show()
        Me.Hide()
    End Sub

    Private Sub Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        VerificarEstadoBotonVentas()
    End Sub
    Private Sub VerificarEstadoBotonVentas()
        Dim cantidadProductos As Integer = 0

        Try
            Using con As New MySqlConnection(cadenaConexion)
                con.Open()

                Dim query As String = "SELECT COUNT(*) FROM productos"
                Dim cmd As New MySqlCommand(query, con)


                cantidadProductos = Convert.ToInt32(cmd.ExecuteScalar())
            End Using
        Catch ex As Exception

            MessageBox.Show("Error al verificar productos: " & ex.Message)
            cantidadProductos = 0
        End Try


        If cantidadProductos > 0 Then

            btnVentas.Enabled = True

            btnVentas.Text = "Ventas"
        Else

            btnVentas.Enabled = False

            btnVentas.Text = "Ventas (Sin productos)"
        End If
    End Sub

    Private Sub Menu_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        VerificarEstadoBotonVentas()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Productos.Show()
        Me.Hide()
    End Sub
End Class