﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnVentas = New Button()
        Button2 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' btnVentas
        ' 
        btnVentas.Enabled = False
        btnVentas.Location = New Point(39, 177)
        btnVentas.Name = "btnVentas"
        btnVentas.Size = New Size(134, 92)
        btnVentas.TabIndex = 0
        btnVentas.Text = "Ventas"
        btnVentas.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(315, 177)
        Button2.Name = "Button2"
        Button2.Size = New Size(134, 92)
        Button2.TabIndex = 1
        Button2.Text = "Productos"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(39, 347)
        Button4.Name = "Button4"
        Button4.Size = New Size(107, 69)
        Button4.TabIndex = 3
        Button4.Text = "Cerrar sesion"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(609, 178)
        Button5.Name = "Button5"
        Button5.Size = New Size(143, 91)
        Button5.TabIndex = 4
        Button5.Text = "Clientes"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(315, 38)
        Label1.Name = "Label1"
        Label1.Size = New Size(84, 15)
        Label1.TabIndex = 5
        Label1.Text = "Elige un boton"
        ' 
        ' Menu
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label1)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(Button2)
        Controls.Add(btnVentas)
        Name = "Menu"
        Text = "Menu"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnVentas As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label1 As Label
End Class
